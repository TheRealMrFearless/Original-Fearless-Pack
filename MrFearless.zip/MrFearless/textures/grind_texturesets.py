import json
import os
from PIL import Image

with open('terrain_texture.json') as f:
    data = json.load(f)
def makeFiles(name):
    print(name)
    textureset={}
    textureset["format_version"]= "1.16.100"
    textSet={}
    textSet["color"]=name
    textSet["metalness_emissive_roughness"]=name + "_MER"
    textSet["heightmap"]=name+"_normal"
    textureset["minecraft:texture_set"]=textSet
    if not(os.path.exists('blocks/{}.texture_set.json'.format(name))):
        with open('blocks/{}.texture_set.json'.format(name), 'w') as json_file:
            json.dump(textureset, json_file)
    if not(os.path.exists('blocks/{}_MER.png'.format(name))):
        img = Image.new('RGBA', (16, 16), (0, 0, 0, 255))
        img.save('blocks/{}_MER.png'.format(name), 'png')
    if not(os.path.exists('blocks/{}_normal.png'.format(name))):
        img = Image.new('L', (16, 16))
        img.save('blocks/{}_normal.png'.format(name), 'png')
            
for texture_name in data["texture_data"].keys():
    if type(data["texture_data"][texture_name]["textures"]) is str:
        makeFiles(data["texture_data"][texture_name]["textures"].split("/")[-1])
    elif type(data["texture_data"][texture_name]["textures"]) is list:
        for name in data["texture_data"][texture_name]["textures"]:
            makeFiles(name.split("/")[-1])
            
